package com.nagarro.assignment2.view;

import java.util.ArrayList;
import java.util.List;

import com.nagarro.assignment2.domain.TShirt;

public class Output {
	
	public void displayAllShirts(List<TShirt> shirtList) {
		System.out.println("List of shirts: ");
		System.out.println("Id | Name | Color | Gender | Size | Price | Rating | Availability");
		for (TShirt s : shirtList) {

			System.out.print(" \n" + s.getId());
			System.out.print("|" + s.getName());
			System.out.print("| + " + s.getColor());
			System.out.print("| + " + s.getGender());
			System.out.print("| + " + s.getSize());
			System.out.print("| + " + s.getPrice());
			System.out.print("| + " + s.getRating());
			System.out.print("| + " + s.getAvailability());
			System.out.println(" ");
		}
		if (shirtList.isEmpty()) {
			System.out.println("No Shirts available");
		}
	}

}
