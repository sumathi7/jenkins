package com.nagarro.assignment2.view;

import java.util.Scanner;

import com.nagarro.assignment2.dto.TShirtSearchDTO;

public class Input {
	
	public TShirtSearchDTO getDetails() {
		
		Scanner scanner = new Scanner(System.in);
		String color;
		String size;
		String gender;
		int outputPreference;

		System.out.print("Enter color  : ");
		color = scanner.nextLine();
		System.out.print("Enter size  : ");
		size = scanner.nextLine();
		System.out.print("Gender   : ");
		gender = scanner.nextLine();
		System.out.print("Enter Output Preference :1.Price/2.Rating: ");
		outputPreference = scanner.nextInt();
		System.out.println(outputPreference);		


		TShirtSearchDTO tShirtsDto = new TShirtSearchDTO();
		tShirtsDto.setColor(color);
		tShirtsDto.setSize(size);
		tShirtsDto.setGender(gender);

		tShirtsDto.setOutputPreference(outputPreference);
		
		return tShirtsDto;
	}

}
