package com.nagarro.assignment2.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import com.nagarro.assignment2.domain.TShirt;
import com.nagarro.assignment2.dto.TShirtSearchDTO;
import com.nagarro.assignment2.dto.TShirtSearchDTO;

public class TShirtSearchService {

		public List<TShirt> getMatchingTShirts(TShirtSearchDTO tShirtSearchDTO) throws IOException {
			List<TShirt> allTShirts;

			ArrayList<TShirt> matchedTShirts = new ArrayList<TShirt>();

			allTShirts = getAllTShirts();

			for (TShirt tShirt : allTShirts) {
				if (tShirt.getColor().equals(tShirtSearchDTO.getColor())
						&& tShirt.getGender().equals(tShirtSearchDTO.getGender())
						&& tShirt.getSize().equals(tShirtSearchDTO.getSize())) {
					matchedTShirts.add(tShirt);
				}
			}
			return matchedTShirts;
		}
	
	
	public List<TShirt> getAllTShirts() {
		TShirt obj1 = new TShirt();

		Configuration con = new Configuration().configure().addAnnotatedClass(TShirt.class);
		SessionFactory sessionFactory = con.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t = session.beginTransaction();

		Query q = session.createQuery("from TShirt");
		List<TShirt> e = q.list();
		
		return e;

	}

}